// Server-only. Never import from a Client Component — reads raw API keys
// from process.env and must not leak into any bundle sent to the browser.

type ProviderName = "groq" | "gemini";

interface RotationState {
  groqKeys: string[];
  geminiKeys: string[];
  groqIndex: number;
  geminiIndex: number;
}

// Module-level state persists across warm invocations on the same
// serverless instance, giving true round-robin behavior request-to-request.
const state: RotationState = {
  groqKeys: parseKeys(process.env.GROQ_API_KEY, process.env.GROQ_API_KEYS),
  geminiKeys: parseKeys(process.env.GEMINI_API_KEY, process.env.GEMINI_API_KEYS),
  groqIndex: 0,
  geminiIndex: 0
};

function parseKeys(single?: string, list?: string): string[] {
  const keys = new Set<string>();
  if (single) keys.add(single.trim());
  if (list) {
    list
      .split(",")
      .map((k) => k.trim())
      .filter(Boolean)
      .forEach((k) => keys.add(k));
  }
  return Array.from(keys);
}

function nextKey(provider: ProviderName): string | null {
  const keys = provider === "groq" ? state.groqKeys : state.geminiKeys;
  if (keys.length === 0) return null;
  const idx = provider === "groq" ? state.groqIndex : state.geminiIndex;
  const key = keys[idx % keys.length];
  if (provider === "groq") state.groqIndex = (idx + 1) % keys.length;
  else state.geminiIndex = (idx + 1) % keys.length;
  return key;
}

function isRetryableStatus(status: number) {
  return status === 429 || status === 401 || status === 403 || status >= 500;
}

async function callGroq(key: string, prompt: string, signal: AbortSignal) {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.4,
      max_tokens: 4000
    }),
    signal
  });

  if (!res.ok) {
    const err: any = new Error(`Groq error ${res.status}`);
    err.status = res.status;
    throw err;
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content as string;
}

async function callGemini(key: string, prompt: string, signal: AbortSignal) {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.4, maxOutputTokens: 4000 }
      }),
      signal
    }
  );

  if (!res.ok) {
    const err: any = new Error(`Gemini error ${res.status}`);
    err.status = res.status;
    throw err;
  }

  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text as string;
}

/**
 * Generates a completion using round-robin key rotation across Groq first,
 * then Gemini as failover. Tries every available key for a provider before
 * moving to the next provider. Throws a user-friendly error only if every
 * key on every provider has failed.
 */
export async function generateCompletion(prompt: string): Promise<string> {
  const attempts: string[] = [];
  const timeoutMs = 25000;

  for (const provider of ["groq", "gemini"] as ProviderName[]) {
    const keyCount = provider === "groq" ? state.groqKeys.length : state.geminiKeys.length;

    for (let i = 0; i < keyCount; i++) {
      const key = nextKey(provider);
      if (!key) break;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const text =
          provider === "groq"
            ? await callGroq(key, prompt, controller.signal)
            : await callGemini(key, prompt, controller.signal);

        clearTimeout(timeout);
        if (text && text.trim().length > 0) return text;
        attempts.push(`${provider}: empty response`);
      } catch (err: any) {
        clearTimeout(timeout);
        const status = err?.status;
        const isTimeout = err?.name === "AbortError";
        attempts.push(
          `${provider} key #${i + 1}: ${isTimeout ? "timeout" : status ?? err?.message ?? "network error"}`
        );
        // Retryable failure (429/401/403/5xx/timeout/network) -> loop continues
        // to the next key automatically. Non-retryable errors also just move
        // on, since we never want a single bad key to halt generation.
        if (status && !isRetryableStatus(status) && !isTimeout) {
          // Still continue to next key rather than aborting the whole provider.
        }
        continue;
      }
    }
  }

  console.error("AI provider rotation exhausted:", attempts.join(" | "));
  throw new Error(
    "Our AI providers are temporarily unavailable. Please try again in a moment."
  );
}
