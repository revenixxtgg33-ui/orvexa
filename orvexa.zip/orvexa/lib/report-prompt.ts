import type { SiteExtract } from "./firecrawl";

export interface OrvexaReport {
  seoScore: number;
  leadScore: number;
  biggestIssues: string[];
  businessImpact: string;
  quickWins: string[];
  bestSalesAngle: string;
  coldEmail: string;
  linkedinDm: string;
  followUp: string;
  priorityFixes: { title: string; detail: string }[];
}

export function buildReportPrompt(extract: SiteExtract): string {
  const headingsSummary = extract.headings
    .slice(0, 25)
    .map((h) => `${h.level.toUpperCase()}: ${h.text}`)
    .join("\n");

  const imagesMissingAlt = extract.images.filter((i) => !i.alt?.trim()).length;

  return `You are a senior SEO consultant preparing a sales-facing audit for an agency
that will pitch this exact prospect. Base every observation strictly on the
extracted data below — never invent facts, never write generic filler.
If a data point is missing, say so plainly rather than guessing.

WEBSITE: ${extract.url}
TITLE TAG: ${extract.title || "(missing)"}
META DESCRIPTION: ${extract.metaDescription || "(missing)"}
CANONICAL URL: ${extract.canonicalUrl}
HEADINGS FOUND:
${headingsSummary || "(none found)"}
TOTAL IMAGES: ${extract.images.length} (${imagesMissingAlt} missing alt text)
INTERNAL LINKS FOUND: ${extract.internalLinks.length}
EXTERNAL LINKS FOUND: ${extract.externalLinks.length}
VISIBLE PAGE TEXT (truncated):
"""
${extract.visibleText.slice(0, 6000)}
"""

Return ONLY valid JSON, no markdown fences, no commentary, matching exactly
this shape:

{
  "seoScore": number (0-100, based on title/meta/headings/content/technical signals actually observed),
  "leadScore": number (0-100, how promising this prospect is as a paying client based on gaps found),
  "biggestIssues": string[] (3-5 issues, each referencing a specific finding above, e.g. missing title tag, thin content, no H1, missing alt text count, weak meta description length),
  "businessImpact": string (2-3 sentences on what these specific issues cost the business in plain commercial terms),
  "quickWins": string[] (3-5 concrete fixes referencing the actual findings, doable in under a week),
  "bestSalesAngle": string (1-2 sentences: the single sharpest hook an agency should lead with, grounded in a specific finding),
  "coldEmail": string (a full cold email, 120-160 words, referencing the site by name/URL and at least two specific findings, signed generically as '[Your Name]'),
  "linkedinDm": string (a short LinkedIn DM, under 80 words, casual but specific to one finding),
  "followUp": string (a brief follow-up message for 4-5 days later if no reply, under 60 words),
  "priorityFixes": [{"title": string, "detail": string}] (3-4 items, ordered by impact, each detail citing the specific on-site evidence)
}`;
}

export function parseReportJson(raw: string): OrvexaReport {
  const cleaned = raw
    .trim()
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```\s*$/i, "");

  const parsed = JSON.parse(cleaned);

  return {
    seoScore: clampScore(parsed.seoScore),
    leadScore: clampScore(parsed.leadScore),
    biggestIssues: asStringArray(parsed.biggestIssues),
    businessImpact: String(parsed.businessImpact ?? "").trim(),
    quickWins: asStringArray(parsed.quickWins),
    bestSalesAngle: String(parsed.bestSalesAngle ?? "").trim(),
    coldEmail: String(parsed.coldEmail ?? "").trim(),
    linkedinDm: String(parsed.linkedinDm ?? "").trim(),
    followUp: String(parsed.followUp ?? "").trim(),
    priorityFixes: Array.isArray(parsed.priorityFixes)
      ? parsed.priorityFixes
          .filter((f: any) => f && f.title)
          .map((f: any) => ({ title: String(f.title), detail: String(f.detail ?? "") }))
      : []
  };
}

function clampScore(n: unknown) {
  const num = Number(n);
  if (Number.isNaN(num)) return 0;
  return Math.max(0, Math.min(100, Math.round(num)));
}

function asStringArray(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v.map((x) => String(x)).filter(Boolean);
}
