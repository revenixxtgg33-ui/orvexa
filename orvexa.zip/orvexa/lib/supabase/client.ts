import { createBrowserClient } from "@supabase/ssr";

// Frontend client — uses ONLY the public anon key. Never import the
// service role key here or anywhere that ships to the browser.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
