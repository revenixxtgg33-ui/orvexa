import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

// Session-aware server client (respects RLS as the logged-in user).
// Used inside Server Components and Route Handlers that act "as the user".
export function createServerSupabase() {
  const cookieStore = cookies();
  return createServerClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // Called from a Server Component with no write access — safe to ignore,
            // middleware refreshes the session cookie instead.
          }
        }
      }
    }
  );
}

// Service-role client — SERVER ONLY. Bypasses RLS. Used exclusively inside
// API route handlers for operations the user's own session can't perform
// (quota increments, profile bootstrap, webhook writes). Never import this
// file from a Client Component.
import { createClient as createRawClient } from "@supabase/supabase-js";

export function createServiceSupabase() {
  return createRawClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
