import type { OrvexaReport } from "./report-prompt";

export async function exportReportToPdf(title: string, siteUrl: string, report: OrvexaReport) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 48;
  const pageWidth = doc.internal.pageSize.getWidth();
  const maxWidth = pageWidth - margin * 2;
  let y = margin;

  function heading(text: string, size = 16) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(size);
    doc.text(text, margin, y);
    y += size * 1.1;
  }

  function label(text: string) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(90);
    doc.text(text, margin, y);
    y += 16;
    doc.setTextColor(20);
  }

  function body(text: string) {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10.5);
    const lines = doc.splitTextToSize(text, maxWidth);
    lines.forEach((line: string) => {
      if (y > 780) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += 14;
    });
    y += 8;
  }

  function bulletList(items: string[]) {
    items.forEach((item) => body(`•  ${item}`));
  }

  heading("Orvexa SEO & Sales Report");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(120);
  doc.text(`${title} — ${siteUrl}`, margin, y);
  doc.setTextColor(20);
  y += 26;

  label(`SEO Score: ${report.seoScore}/100    Lead Score: ${report.leadScore}/100`);
  y += 6;

  label("Biggest Issues");
  bulletList(report.biggestIssues);

  label("Business Impact");
  body(report.businessImpact);

  label("Quick Wins");
  bulletList(report.quickWins);

  label("Best Sales Angle");
  body(report.bestSalesAngle);

  label("Priority Fixes");
  report.priorityFixes.forEach((f, i) => body(`${i + 1}. ${f.title} — ${f.detail}`));

  label("Cold Email");
  body(report.coldEmail);

  label("LinkedIn DM");
  body(report.linkedinDm);

  label("Follow-Up");
  body(report.followUp);

  doc.save(`${title.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-orvexa-report.pdf`);
}
