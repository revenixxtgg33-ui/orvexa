// Server-only. Uses FIRECRAWL_API_KEY from the environment — never expose
// this module or the key to the client bundle.

export interface SiteExtract {
  url: string;
  title: string;
  metaDescription: string;
  canonicalUrl: string;
  headings: { level: string; text: string }[];
  visibleText: string;
  internalLinks: string[];
  externalLinks: string[];
  images: { src: string; alt: string }[];
  structuredData: unknown[];
  source: "firecrawl" | "fallback";
}

export async function extractSite(url: string): Promise<SiteExtract> {
  try {
    return await extractWithFirecrawl(url);
  } catch (err) {
    console.warn("Firecrawl extraction failed, using fallback scraper:", err);
    return await extractWithFallback(url);
  }
}

async function extractWithFirecrawl(url: string): Promise<SiteExtract> {
  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) throw new Error("FIRECRAWL_API_KEY missing");

  const res = await fetch("https://api.firecrawl.dev/v1/scrape", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      url,
      formats: ["markdown", "html", "links"],
      onlyMainContent: false
    }),
    signal: AbortSignal.timeout(20000)
  });

  if (!res.ok) throw new Error(`Firecrawl responded ${res.status}`);

  const data = await res.json();
  const doc = data?.data ?? data;
  const html: string = doc?.html ?? "";
  const metadata = doc?.metadata ?? {};

  const headings = extractHeadingsFromHtml(html);
  const images = extractImagesFromHtml(html);
  const links: string[] = doc?.links ?? [];
  const { internal, external } = splitLinks(links, url);

  return {
    url,
    title: metadata.title ?? "",
    metaDescription: metadata.description ?? "",
    canonicalUrl: metadata.canonicalUrl ?? url,
    headings,
    visibleText: (doc?.markdown ?? "").slice(0, 12000),
    internalLinks: internal,
    externalLinks: external,
    images,
    structuredData: metadata.jsonLd ? [metadata.jsonLd] : [],
    source: "firecrawl"
  };
}

// Safe fallback: a plain fetch + regex-based extraction so the app never
// crashes if Firecrawl is down or the key is missing.
async function extractWithFallback(url: string): Promise<SiteExtract> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(15000),
    headers: { "User-Agent": "OrvexaBot/1.0 (+https://orvexa.app)" }
  });
  const html = await res.text();

  const title = /<title>(.*?)<\/title>/i.exec(html)?.[1]?.trim() ?? "";
  const metaDescription =
    /<meta\s+name=["']description["']\s+content=["'](.*?)["']/i.exec(html)?.[1] ?? "";
  const canonical =
    /<link\s+rel=["']canonical["']\s+href=["'](.*?)["']/i.exec(html)?.[1] ?? url;

  const headings = extractHeadingsFromHtml(html);
  const images = extractImagesFromHtml(html);
  const links = Array.from(html.matchAll(/href=["'](.*?)["']/gi)).map((m) => m[1]);
  const { internal, external } = splitLinks(links, url);

  const visibleText = html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 8000);

  return {
    url,
    title,
    metaDescription,
    canonicalUrl: canonical,
    headings,
    visibleText,
    internalLinks: internal,
    externalLinks: external,
    images,
    structuredData: [],
    source: "fallback"
  };
}

function extractHeadingsFromHtml(html: string) {
  const headings: { level: string; text: string }[] = [];
  const re = /<h([1-6])[^>]*>(.*?)<\/h\1>/gis;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    headings.push({
      level: `h${m[1]}`,
      text: m[2].replace(/<[^>]+>/g, "").trim()
    });
  }
  return headings.slice(0, 60);
}

function extractImagesFromHtml(html: string) {
  const images: { src: string; alt: string }[] = [];
  const re = /<img[^>]*src=["'](.*?)["'][^>]*?(?:alt=["'](.*?)["'])?[^>]*>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    images.push({ src: m[1], alt: m[2] ?? "" });
  }
  return images.slice(0, 30);
}

function splitLinks(links: string[], baseUrl: string) {
  const host = safeHost(baseUrl);
  const internal: string[] = [];
  const external: string[] = [];
  for (const link of links) {
    if (!link || link.startsWith("#") || link.startsWith("mailto:")) continue;
    const linkHost = safeHost(link, baseUrl);
    if (!linkHost) continue;
    if (linkHost === host) internal.push(link);
    else external.push(link);
  }
  return {
    internal: Array.from(new Set(internal)).slice(0, 40),
    external: Array.from(new Set(external)).slice(0, 20)
  };
}

function safeHost(url: string, base?: string) {
  try {
    return new URL(url, base).host;
  } catch {
    return null;
  }
}
