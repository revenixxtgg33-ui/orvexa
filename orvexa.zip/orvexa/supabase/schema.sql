-- REFERENCE ONLY. Do not run this if your three tables already exist with
-- different names/columns — instead rename the columns referenced in
-- lib/supabase queries throughout /app/api to match your real schema.
--
-- Orvexa expects exactly three tables, used as the single source of truth:
--   1. profiles      -> user identity, plan, quota
--   2. reports       -> generated report history
--   3. subscriptions -> Polar billing / plan state
--
-- RLS: every table is scoped to auth.uid() = user_id. All writes that need
-- to bypass RLS (quota increments, webhook updates) go through the
-- service-role client in lib/supabase/server.ts, server-side only.

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  avatar_url text,
  plan text not null default 'free',           -- free | starter | pro | agency
  reports_quota integer not null default 3,
  reports_used integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  site_url text not null,
  title text not null,
  report_json jsonb not null,
  extract_source text not null default 'firecrawl', -- firecrawl | fallback
  created_at timestamptz not null default now()
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  polar_customer_id text,
  polar_subscription_id text,
  plan text not null default 'free',
  status text not null default 'active',        -- active | past_due | canceled
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table reports enable row level security;
alter table subscriptions enable row level security;

create policy "profiles self access" on profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "reports self access" on reports
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "subscriptions self read" on subscriptions
  for select using (auth.uid() = user_id);
