import Link from "next/link";
import { ArrowRight, PlayCircle } from "lucide-react";

export default function Hero() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-20 pt-24 text-center md:pt-32">
      <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-base-border bg-base-900 px-4 py-1.5 text-xs text-white/60">
        <span className="h-1.5 w-1.5 rounded-full bg-accent" />
        Built for SEO agencies that sell
      </div>

      <h1 className="mx-auto max-w-3xl text-4xl font-semibold leading-[1.15] tracking-tight md:text-6xl">
        Turn any prospect website into a sales angle in seconds.
      </h1>

      <p className="mx-auto mt-6 max-w-xl text-balance text-lg text-white/55">
        Audit the site. Find the opportunity. Write the pitch.
      </p>

      <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <Link href="/dashboard" className="btn-primary px-6 py-3 text-[15px] shadow-glow">
          Generate Report
          <ArrowRight className="h-4 w-4" />
        </Link>
        <a href="#how-it-works" className="btn-secondary px-6 py-3 text-[15px]">
          <PlayCircle className="h-4 w-4" />
          See How It Works
        </a>
      </div>
    </section>
  );
}
