import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function FinalCTA() {
  return (
    <section className="mx-auto max-w-4xl px-6 py-20">
      <div className="card flex flex-col items-center gap-5 p-12 text-center shadow-glow">
        <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">
          Ready to turn your next prospect into a client?
        </h2>
        <p className="max-w-md text-white/50">
          Generate your first report free — no credit card required.
        </p>
        <Link href="/dashboard" className="btn-primary px-6 py-3 text-[15px]">
          Generate Report
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}
