"use client";

import { Check } from "lucide-react";
import Link from "next/link";

const plans = [
  {
    name: "Free",
    price: "$0",
    tag: "3 reports",
    features: ["3 full reports", "Cold email + LinkedIn DM", "PDF export"],
    plan: null
  },
  {
    name: "Starter",
    price: "$29",
    tag: "/mo",
    features: ["50 reports / mo", "Full report history", "Priority generation"],
    plan: "starter"
  },
  {
    name: "Pro",
    price: "$49",
    tag: "/mo",
    features: ["150 reports / mo", "Everything in Starter", "Faster AI routing"],
    plan: "pro",
    highlighted: true
  },
  {
    name: "Agency",
    price: "$79",
    tag: "/mo",
    features: ["500 reports / mo", "Everything in Pro", "Built for teams"],
    plan: "agency"
  }
];

export default function Pricing() {
  async function upgrade(plan: string) {
    const res = await fetch("/api/polar/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan })
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  }

  return (
    <section id="pricing" className="mx-auto max-w-6xl px-6 py-20">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">Simple, transparent pricing</h2>
        <p className="mt-3 text-white/50">Start free. Upgrade when you're closing deals with it.</p>
      </div>

      <div className="grid gap-5 md:grid-cols-4">
        {plans.map((p) => (
          <div
            key={p.name}
            className={`card relative flex flex-col p-6 ${p.highlighted ? "border-accent/50 shadow-glow" : ""}`}
          >
            {p.highlighted && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-accent px-3 py-1 text-xs font-medium">
                Most popular
              </span>
            )}
            <h3 className="text-sm font-medium text-white/70">{p.name}</h3>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="text-3xl font-semibold">{p.price}</span>
              <span className="text-sm text-white/40">{p.tag}</span>
            </div>
            <ul className="mt-6 flex-1 space-y-2.5">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-white/60">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent-soft" />
                  {f}
                </li>
              ))}
            </ul>
            {p.plan ? (
              <button onClick={() => upgrade(p.plan!)} className="btn-primary mt-6 w-full">
                Upgrade
              </button>
            ) : (
              <Link href="/dashboard" className="btn-secondary mt-6 w-full">
                Get started
              </Link>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
