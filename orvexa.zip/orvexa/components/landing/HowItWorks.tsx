const steps = [
  {
    n: "01",
    title: "Paste a prospect's URL",
    desc: "Drop any website into Orvexa — no setup, no manual research."
  },
  {
    n: "02",
    title: "We audit and analyze",
    desc: "Firecrawl extracts the site, then Orvexa scores it and finds the real gaps."
  },
  {
    n: "03",
    title: "Get the report and the pitch",
    desc: "A full SEO breakdown plus a cold email, DM, and follow-up ready to send."
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="mx-auto max-w-5xl px-6 py-20">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">How it works</h2>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {steps.map((s) => (
          <div key={s.n} className="card p-7">
            <div className="mb-4 text-sm font-medium text-accent-soft">{s.n}</div>
            <h3 className="mb-2 text-[15px] font-semibold">{s.title}</h3>
            <p className="text-sm leading-relaxed text-white/50">{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
