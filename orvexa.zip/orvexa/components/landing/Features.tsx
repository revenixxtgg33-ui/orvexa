import { Radar, Mail, FileBarChart, Zap } from "lucide-react";

const features = [
  {
    icon: Radar,
    title: "Real site audits",
    desc: "Firecrawl extracts titles, headings, meta data, links, and content — no guessing, no generic templates."
  },
  {
    icon: FileBarChart,
    title: "Consultant-grade reports",
    desc: "SEO score, lead score, business impact, and priority fixes written like a senior consultant, not a chatbot."
  },
  {
    icon: Mail,
    title: "Ready-to-send outreach",
    desc: "A cold email, a LinkedIn DM, and a follow-up — all grounded in what's actually wrong with the site."
  },
  {
    icon: Zap,
    title: "Built for volume",
    desc: "Round-robin AI routing across providers keeps generation fast and reliable, even under load."
  }
];

export default function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl px-6 py-20">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
          Everything an agency needs to close the deal
        </h2>
      </div>
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <div key={f.title} className="card p-6">
            <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15">
              <f.icon className="h-5 w-5 text-accent-soft" />
            </div>
            <h3 className="mb-2 text-[15px] font-semibold">{f.title}</h3>
            <p className="text-sm leading-relaxed text-white/50">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
