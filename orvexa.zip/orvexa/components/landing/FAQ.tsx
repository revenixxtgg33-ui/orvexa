const faqs = [
  {
    q: "How is this different from a generic AI SEO tool?",
    a: "Orvexa is built for the sales conversation, not just the audit. Every report comes with a cold email, a DM, and a follow-up already written, grounded in what was actually found on the site."
  },
  {
    q: "What happens after my 3 free reports?",
    a: "Report generation pauses until you upgrade. Your history, exports, and account stay fully intact."
  },
  {
    q: "Which sites can Orvexa analyze?",
    a: "Any public website. Orvexa crawls it directly and falls back automatically if a site blocks standard extraction."
  },
  {
    q: "Can I cancel anytime?",
    a: "Yes — billing is handled through Polar and you can cancel from your account at any time."
  }
];

export default function FAQ() {
  return (
    <section id="faq" className="mx-auto max-w-3xl px-6 py-20">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">Frequently asked questions</h2>
      </div>
      <div className="space-y-4">
        {faqs.map((f) => (
          <div key={f.q} className="card p-6">
            <h3 className="mb-2 text-[15px] font-semibold">{f.q}</h3>
            <p className="text-sm leading-relaxed text-white/50">{f.a}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
