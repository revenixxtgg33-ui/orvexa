import Image from "next/image";

export default function Footer() {
  return (
    <footer className="border-t border-base-border/60 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-sm text-white/40 md:flex-row">
        <div className="flex items-center gap-2 select-none">
          <Image src="/logo.svg" alt="" width={20} height={20} />
          <span className="font-medium text-white/60">Orvexa</span>
        </div>
        <p>© {new Date().getFullYear()} Orvexa. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#pricing" className="transition hover:text-white/70">Pricing</a>
          <a href="#faq" className="transition hover:text-white/70">FAQ</a>
        </div>
      </div>
    </footer>
  );
}
