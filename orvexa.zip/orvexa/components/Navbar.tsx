"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function Navbar() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const searchParams = useSearchParams();
  const supabase = createClient();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setAuthed(!!data.user));
  }, [supabase]);

  useEffect(() => {
    if (searchParams.get("login") === "1" && authed === false) {
      signIn();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authed]);

  async function signIn() {
    const next = searchParams.get("next") || "/dashboard";
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}` }
    });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-base-border/60 bg-base-950/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2.5 select-none" aria-label="Orvexa">
          <Image src="/logo.svg" alt="" width={28} height={28} priority />
          <span className="text-[15px] font-semibold tracking-tight">Orvexa</span>
        </div>

        <nav className="hidden items-center gap-8 text-sm text-white/60 md:flex">
          <a href="#features" className="transition hover:text-white">Features</a>
          <a href="#how-it-works" className="transition hover:text-white">How it works</a>
          <a href="#pricing" className="transition hover:text-white">Pricing</a>
          <a href="#faq" className="transition hover:text-white">FAQ</a>
        </nav>

        <div className="flex items-center gap-3">
          {authed ? (
            <Link href="/dashboard" className="btn-primary">
              Generate Report
            </Link>
          ) : (
            <button onClick={signIn} className="btn-primary">
              Sign in with Google
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
