"use client";

import { useState } from "react";
import { Loader2, Sparkles } from "lucide-react";
import type { OrvexaReport } from "@/lib/report-prompt";

interface Props {
  reportsRemaining: number;
  onGenerated: (report: {
    id: string;
    title: string;
    site_url: string;
    report_json: OrvexaReport;
    created_at: string;
  }) => void;
}

export default function UrlInputCard({ reportsRemaining, onGenerated }: Props) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const blocked = reportsRemaining <= 0;

  async function handleGenerate() {
    if (!url.trim() || loading || blocked) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/generate-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() })
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Something went wrong.");
        return;
      }

      onGenerated(data.report);
      setUrl("");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card p-6">
      <h2 className="mb-1 text-[15px] font-semibold">Generate a report</h2>
      <p className="mb-5 text-sm text-white/45">
        Paste a prospect's website and Orvexa will audit it and write the pitch.
      </p>

      <div className="flex flex-col gap-3 sm:flex-row">
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
          placeholder="https://prospect-website.com"
          disabled={blocked}
          className="input-field disabled:cursor-not-allowed disabled:opacity-50"
        />
        <button
          onClick={handleGenerate}
          disabled={loading || blocked || !url.trim()}
          className="btn-primary shrink-0 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {loading ? "Analyzing…" : "Generate"}
        </button>
      </div>

      {blocked && (
        <p className="mt-3 text-sm text-amber-400/90">
          You've used all your free reports. Upgrade to keep generating.
        </p>
      )}
      {error && <p className="mt-3 text-sm text-red-400/90">{error}</p>}
    </div>
  );
}
