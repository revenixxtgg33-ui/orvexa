"use client";

import { useEffect, useState, useCallback } from "react";
import { Search, Pencil, Trash2, FileText, Check, X } from "lucide-react";
import type { OrvexaReport } from "@/lib/report-prompt";

export interface ReportRow {
  id: string;
  title: string;
  site_url: string;
  report_json: OrvexaReport;
  created_at: string;
}

interface Props {
  initialReports: ReportRow[];
  onSelect: (report: ReportRow) => void;
  activeId?: string;
}

export default function HistoryList({ initialReports, onSelect, activeId }: Props) {
  const [reports, setReports] = useState(initialReports);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const search = useCallback(async (q: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/reports?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (res.ok) setReports(data.reports);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => search(query), 300);
    return () => clearTimeout(t);
  }, [query, search]);

  async function saveRename(id: string) {
    if (!editTitle.trim()) return;
    const res = await fetch(`/api/reports/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: editTitle.trim() })
    });
    if (res.ok) {
      setReports((prev) => prev.map((r) => (r.id === id ? { ...r, title: editTitle.trim() } : r)));
    }
    setEditingId(null);
  }

  async function handleDelete(id: string) {
    setReports((prev) => prev.filter((r) => r.id !== id));
    await fetch(`/api/reports/${id}`, { method: "DELETE" });
  }

  return (
    <div className="card p-6">
      <h3 className="mb-4 text-sm font-medium text-white/70">History</h3>

      <div className="relative mb-4">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search reports…"
          className="input-field pl-9 text-sm"
        />
      </div>

      {loading && <p className="text-xs text-white/30">Searching…</p>}

      {!loading && reports.length === 0 && (
        <div className="flex flex-col items-center gap-2 py-10 text-center">
          <FileText className="h-6 w-6 text-white/20" />
          <p className="text-sm text-white/40">
            {query ? "No reports match your search." : "No reports yet — generate your first one above."}
          </p>
        </div>
      )}

      <ul className="space-y-1.5">
        {reports.map((r) => (
          <li
            key={r.id}
            className={`group flex items-center gap-2 rounded-lg border px-3 py-2.5 transition ${
              activeId === r.id ? "border-accent/50 bg-accent/10" : "border-transparent hover:bg-base-800"
            }`}
          >
            {editingId === r.id ? (
              <div className="flex flex-1 items-center gap-1.5">
                <input
                  autoFocus
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && saveRename(r.id)}
                  className="input-field py-1.5 text-sm"
                />
                <button onClick={() => saveRename(r.id)} className="rounded p-1 text-emerald-400 hover:bg-base-700">
                  <Check className="h-4 w-4" />
                </button>
                <button onClick={() => setEditingId(null)} className="rounded p-1 text-white/40 hover:bg-base-700">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <>
                <button onClick={() => onSelect(r)} className="min-w-0 flex-1 text-left">
                  <p className="truncate text-sm text-white/85">{r.title}</p>
                  <p className="truncate text-xs text-white/35">{r.site_url}</p>
                </button>
                <div className="flex shrink-0 gap-1 opacity-0 transition group-hover:opacity-100">
                  <button
                    onClick={() => {
                      setEditingId(r.id);
                      setEditTitle(r.title);
                    }}
                    className="rounded p-1.5 text-white/40 hover:bg-base-700 hover:text-white"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(r.id)}
                    className="rounded p-1.5 text-white/40 hover:bg-red-500/15 hover:text-red-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
