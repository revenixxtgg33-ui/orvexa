"use client";

import { createClient } from "@/lib/supabase/client";
import { LogOut, Crown } from "lucide-react";
import { useRouter } from "next/navigation";

interface Props {
  email: string;
  fullName: string;
  avatarUrl: string;
  plan: string;
}

export default function AccountPanel({ email, fullName, avatarUrl, plan }: Props) {
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <div className="card p-6">
      <div className="flex items-center gap-3">
        {avatarUrl ? (
          <img src={avatarUrl} alt="" className="h-11 w-11 rounded-full border border-base-border" />
        ) : (
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/20 text-sm font-medium">
            {(fullName || email)?.[0]?.toUpperCase()}
          </div>
        )}
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{fullName || "Your account"}</p>
          <p className="truncate text-xs text-white/40">{email}</p>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-2 rounded-lg border border-base-border bg-base-850 px-3 py-2">
        <Crown className="h-4 w-4 text-accent-soft" />
        <span className="text-sm capitalize text-white/70">{plan} plan</span>
      </div>

      <div className="mt-4 flex gap-2">
        {plan === "free" && (
          <a href="#pricing" className="btn-primary flex-1 text-sm">
            Upgrade
          </a>
        )}
        <button onClick={handleLogout} className="btn-secondary flex-1 text-sm">
          <LogOut className="h-3.5 w-3.5" />
          Log out
        </button>
      </div>
    </div>
  );
}
