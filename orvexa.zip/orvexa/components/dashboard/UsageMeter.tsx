export default function UsageMeter({ used, quota }: { used: number; quota: number }) {
  const pct = quota > 0 ? Math.min(100, Math.round((used / quota) * 100)) : 0;
  const remaining = Math.max(0, quota - used);

  return (
    <div className="card p-6">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-medium text-white/70">Report usage</h3>
        <span className="text-sm text-white/50">
          {used} / {quota}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-base-800">
        <div
          className={`h-full rounded-full transition-all ${pct >= 100 ? "bg-red-500" : "bg-accent"}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <p className="mt-2.5 text-xs text-white/40">
        {remaining > 0 ? `${remaining} report${remaining === 1 ? "" : "s"} remaining` : "No reports remaining"}
      </p>
    </div>
  );
}
