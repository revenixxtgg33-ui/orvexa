"use client";

import { useState } from "react";
import UrlInputCard from "./UrlInputCard";
import ReportCard from "./ReportCard";
import UsageMeter from "./UsageMeter";
import HistoryList, { ReportRow } from "./HistoryList";
import AccountPanel from "./AccountPanel";
import { FileText } from "lucide-react";

interface Props {
  profile: {
    email: string;
    full_name: string;
    avatar_url: string;
    plan: string;
    reports_quota: number;
    reports_used: number;
  };
  initialReports: ReportRow[];
}

export default function DashboardClient({ profile, initialReports }: Props) {
  const [activeReport, setActiveReport] = useState<ReportRow | null>(initialReports[0] ?? null);
  const [used, setUsed] = useState(profile.reports_used);

  function handleGenerated(report: ReportRow) {
    setActiveReport(report);
    setUsed((u) => u + 1);
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-6 px-6 py-10 lg:grid-cols-[1fr_320px]">
      <div className="min-w-0 space-y-6">
        <UrlInputCard
          reportsRemaining={profile.reports_quota - used}
          onGenerated={handleGenerated}
        />

        {activeReport ? (
          <ReportCard
            title={activeReport.title}
            siteUrl={activeReport.site_url}
            report={activeReport.report_json}
          />
        ) : (
          <div className="card flex flex-col items-center gap-3 py-16 text-center">
            <FileText className="h-8 w-8 text-white/20" />
            <p className="text-sm text-white/40">
              Your first report will appear here once generated.
            </p>
          </div>
        )}
      </div>

      <div className="space-y-6">
        <AccountPanel
          email={profile.email}
          fullName={profile.full_name}
          avatarUrl={profile.avatar_url}
          plan={profile.plan}
        />
        <UsageMeter used={used} quota={profile.reports_quota} />
        <HistoryList
          initialReports={initialReports}
          onSelect={setActiveReport}
          activeId={activeReport?.id}
        />
      </div>
    </div>
  );
}
