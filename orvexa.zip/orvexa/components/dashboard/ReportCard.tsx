"use client";

import { useState } from "react";
import { Copy, Check, Download, TrendingUp, Target } from "lucide-react";
import type { OrvexaReport } from "@/lib/report-prompt";
import { exportReportToPdf } from "@/lib/pdf";

interface Props {
  title: string;
  siteUrl: string;
  report: OrvexaReport;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={async () => {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }}
      className="inline-flex items-center gap-1.5 rounded-md border border-base-border px-2.5 py-1 text-xs text-white/60 transition hover:bg-base-800 hover:text-white"
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

function ScoreRing({ label, score }: { label: string; score: number }) {
  const color = score >= 70 ? "text-emerald-400" : score >= 40 ? "text-amber-400" : "text-red-400";
  return (
    <div className="flex flex-col items-center rounded-lg border border-base-border bg-base-850 px-6 py-4">
      <span className={`text-3xl font-semibold ${color}`}>{score}</span>
      <span className="mt-1 text-xs text-white/45">{label}</span>
    </div>
  );
}

export default function ReportCard({ title, siteUrl, report }: Props) {
  return (
    <div className="card p-6 md:p-8">
      <div className="mb-6 flex flex-col justify-between gap-4 border-b border-base-border pb-6 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-lg font-semibold">{title}</h2>
          <a href={siteUrl} target="_blank" rel="noreferrer" className="text-sm text-white/40 hover:text-accent-soft">
            {siteUrl}
          </a>
        </div>
        <button
          onClick={() => exportReportToPdf(title, siteUrl, report)}
          className="btn-secondary shrink-0 text-sm"
        >
          <Download className="h-3.5 w-3.5" />
          Export PDF
        </button>
      </div>

      <div className="mb-8 flex gap-4">
        <ScoreRing label="SEO Score" score={report.seoScore} />
        <ScoreRing label="Lead Score" score={report.leadScore} />
      </div>

      <Section title="Biggest Issues" icon={TrendingUp}>
        <ul className="space-y-2">
          {report.biggestIssues.map((issue, i) => (
            <li key={i} className="flex gap-2.5 text-sm text-white/70">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-red-400/80" />
              {issue}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Business Impact">
        <p className="text-sm leading-relaxed text-white/60">{report.businessImpact}</p>
      </Section>

      <Section title="Quick Wins">
        <ul className="space-y-2">
          {report.quickWins.map((win, i) => (
            <li key={i} className="flex gap-2.5 text-sm text-white/70">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-400/80" />
              {win}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Priority Fixes" icon={Target}>
        <div className="space-y-3">
          {report.priorityFixes.map((fix, i) => (
            <div key={i} className="rounded-lg border border-base-border bg-base-850 p-4">
              <p className="text-sm font-medium">{i + 1}. {fix.title}</p>
              <p className="mt-1 text-sm text-white/50">{fix.detail}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Best Sales Angle">
        <p className="rounded-lg border border-accent/25 bg-accent/10 p-4 text-sm leading-relaxed text-white/80">
          {report.bestSalesAngle}
        </p>
      </Section>

      <Section title="Cold Email" action={<CopyButton text={report.coldEmail} />}>
        <p className="whitespace-pre-wrap rounded-lg border border-base-border bg-base-850 p-4 text-sm leading-relaxed text-white/70">
          {report.coldEmail}
        </p>
      </Section>

      <Section title="LinkedIn DM" action={<CopyButton text={report.linkedinDm} />}>
        <p className="whitespace-pre-wrap rounded-lg border border-base-border bg-base-850 p-4 text-sm leading-relaxed text-white/70">
          {report.linkedinDm}
        </p>
      </Section>

      <Section title="Follow-Up" action={<CopyButton text={report.followUp} />} last>
        <p className="whitespace-pre-wrap rounded-lg border border-base-border bg-base-850 p-4 text-sm leading-relaxed text-white/70">
          {report.followUp}
        </p>
      </Section>
    </div>
  );
}

function Section({
  title,
  icon: Icon,
  action,
  last,
  children
}: {
  title: string;
  icon?: any;
  action?: React.ReactNode;
  last?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`mb-6 ${last ? "" : "border-b border-base-border/60 pb-6"}`}>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white/85">
          {Icon && <Icon className="h-4 w-4 text-accent-soft" />}
          {title}
        </h3>
        {action}
      </div>
      {children}
    </div>
  );
}
