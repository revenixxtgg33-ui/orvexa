# Orvexa — AI SEO Sales Copilot

Dashboard-first SaaS for SEO agencies: paste a prospect's URL, get a
consultant-grade audit plus a ready-to-send cold email, LinkedIn DM, and
follow-up. Built with Next.js 14 (App Router), Supabase, Firecrawl, Groq +
Gemini (round-robin), and Polar billing.

## 1. Before you deploy — reconcile the schema

This build assumes **three Supabase tables**: `profiles`, `reports`,
`subscriptions`. A reference definition lives in `supabase/schema.sql`
(not auto-executed). If your existing three tables use different names or
columns, update the `.from("...")` calls in:

- `app/api/generate-report/route.ts`
- `app/api/reports/route.ts`
- `app/api/reports/[id]/route.ts`
- `app/auth/callback/route.ts`
- `app/api/polar/webhook/route.ts`
- `app/dashboard/page.tsx`

No new tables are created by the app at runtime.

## 2. Environment variables (Vercel → Settings → Environment Variables)

| Variable | Notes |
|---|---|
| `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | Service role is server-only, never sent to the client |
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Safe to expose — anon key only |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Configured in Supabase Dashboard → Authentication → Providers → Google, not read directly by the app |
| `FIRECRAWL_API_KEY` | Primary extraction engine; falls back to a built-in scraper if unset or failing |
| `GROQ_API_KEY`, `GROQ_API_KEYS` | Single key and/or comma-separated list — both are merged into the rotation pool |
| `GEMINI_API_KEY`, `GEMINI_API_KEYS` | Same pattern; used as failover after Groq |
| `POLAR_ACCESS_TOKEN`, `POLAR_WEBHOOK_SECRET` | Billing + webhook signature verification |
| `POLAR_PRODUCT_STARTER`, `POLAR_PRODUCT_PRO`, `POLAR_PRODUCT_AGENCY` | Polar product IDs for each paid tier |
| `NEXT_PUBLIC_SITE_URL` | Used for OAuth + checkout redirect URLs |

All server-only keys are read exclusively inside `/app/api/*` route handlers
and `/lib/*` server modules — never in a `"use client"` file.

## 3. Local development

```bash
npm install
cp .env.example .env.local   # fill in values
npm run dev
```

## 4. Deploy

1. Push to GitHub.
2. Import the repo in Vercel.
3. Add the environment variables above.
4. Add the Vercel deployment URL as an authorized redirect URI in your
   Google OAuth client and in Supabase Auth settings
   (`https://<your-domain>/auth/callback`).
5. Point your Polar webhook endpoint at
   `https://<your-domain>/api/polar/webhook`.
6. Deploy. `npm run build` must succeed with no additional configuration.

## 5. How the AI round-robin works

`lib/ai-provider.ts` parses `GROQ_API_KEY` + `GROQ_API_KEYS` and
`GEMINI_API_KEY` + `GEMINI_API_KEYS` into two key pools, rotating
sequentially on every call. On a `429/401/403/5xx`, timeout, or network
error, it immediately advances to the next key; if every Groq key fails it
fails over to Gemini. Only if every key on both providers fails does it
surface a single user-friendly error.

## 6. Logo

`public/logo.svg` is a pure-white, transparent mark used in the navbar,
footer, and browser tab. It is purely decorative — it has no click handler
and is never wired to logout or navigation.
