import { Suspense } from "react";
import { redirect } from "next/navigation";
import { createServerSupabase } from "@/lib/supabase/server";
import Navbar from "@/components/Navbar";
import DashboardClient from "@/components/dashboard/DashboardClient";

export default async function DashboardPage() {
  const supabase = createServerSupabase();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    redirect(
      `/?login=1&next=${encodeURIComponent("/dashboard")}`
    );
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("email, full_name, avatar_url, plan, reports_quota, reports_used")
    .eq("id", user!.id)
    .single();

  const { data: reports } = await supabase
    .from("reports")
    .select("id, title, site_url, report_json, created_at")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  return (
    <>
      <Suspense fallback={null}>
        <Navbar />
      </Suspense>
      <DashboardClient
        profile={
          profile ?? {
            email: user!.email ?? "",
            full_name: "",
            avatar_url: "",
            plan: "free",
            reports_quota: 3,
            reports_used: 0
          }
        }
        initialReports={reports ?? []}
      />
    </>
  );
}
