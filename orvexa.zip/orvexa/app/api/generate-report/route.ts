import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";
import { extractSite } from "@/lib/firecrawl";
import { generateCompletion } from "@/lib/ai-provider";
import { buildReportPrompt, parseReportJson } from "@/lib/report-prompt";

export const runtime = "nodejs";
export const maxDuration = 60;

function isValidUrl(value: string) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const siteUrl = body?.url?.trim();

  if (!siteUrl || !isValidUrl(siteUrl)) {
    return NextResponse.json({ error: "Enter a valid website URL." }, { status: 400 });
  }

  // Service-role client for the quota check + increment + report insert —
  // keeps this all server-side and atomic-ish, independent of RLS timing.
  const service = createServiceSupabase();

  const { data: profile, error: profileErr } = await service
    .from("profiles")
    .select("id, plan, reports_quota, reports_used")
    .eq("id", user.id)
    .single();

  if (profileErr || !profile) {
    return NextResponse.json({ error: "Profile not found." }, { status: 404 });
  }

  if (profile.reports_used >= profile.reports_quota) {
    return NextResponse.json(
      { error: "You've used all your reports. Upgrade to generate more.", quotaExceeded: true },
      { status: 402 }
    );
  }

  let extract;
  try {
    extract = await extractSite(siteUrl);
  } catch (err) {
    console.error("Extraction failed completely:", err);
    return NextResponse.json(
      { error: "We couldn't access that website. Check the URL and try again." },
      { status: 422 }
    );
  }

  let reportJson;
  try {
    const prompt = buildReportPrompt(extract);
    const raw = await generateCompletion(prompt);
    reportJson = parseReportJson(raw);
  } catch (err: any) {
    console.error("Report generation failed:", err);
    return NextResponse.json(
      { error: err?.message || "Report generation failed. Please try again." },
      { status: 502 }
    );
  }

  const title = extract.title?.trim() || new URL(siteUrl).hostname;

  const { data: savedReport, error: insertErr } = await service
    .from("reports")
    .insert({
      user_id: user.id,
      site_url: siteUrl,
      title,
      report_json: reportJson,
      extract_source: extract.source
    })
    .select()
    .single();

  if (insertErr) {
    console.error("Failed to save report:", insertErr);
    return NextResponse.json({ error: "Report generated but failed to save." }, { status: 500 });
  }

  const { error: quotaErr } = await service
    .from("profiles")
    .update({ reports_used: profile.reports_used + 1 })
    .eq("id", user.id);

  if (quotaErr) {
    console.error("Failed to increment quota:", quotaErr);
  }

  return NextResponse.json({ report: savedReport });
}
