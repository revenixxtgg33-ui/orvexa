import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "crypto";
import { createServiceSupabase } from "@/lib/supabase/server";

export const runtime = "nodejs";

const PLAN_QUOTAS: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 150,
  agency: 500
};

function verifySignature(payload: string, signature: string | null): boolean {
  const secret = process.env.POLAR_WEBHOOK_SECRET;
  if (!secret || !signature) return false;

  const expected = createHmac("sha256", secret).update(payload).digest("hex");
  const sigBuf = Buffer.from(signature);
  const expBuf = Buffer.from(expected);

  if (sigBuf.length !== expBuf.length) return false;
  return timingSafeEqual(sigBuf, expBuf);
}

export async function POST(req: NextRequest) {
  const payload = await req.text();
  const signature = req.headers.get("polar-signature") ?? req.headers.get("webhook-signature");

  if (!verifySignature(payload, signature)) {
    return NextResponse.json({ error: "Invalid signature." }, { status: 401 });
  }

  const event = JSON.parse(payload);
  const service = createServiceSupabase();

  const type = event.type as string;
  const data = event.data;

  try {
    switch (type) {
      case "subscription.created":
      case "subscription.updated":
      case "subscription.active": {
        const userId = data?.metadata?.user_id;
        const plan = data?.metadata?.plan ?? "starter";
        if (!userId) break;

        await service.from("subscriptions").upsert(
          {
            user_id: userId,
            polar_customer_id: data.customer_id,
            polar_subscription_id: data.id,
            plan,
            status: "active",
            current_period_end: data.current_period_end,
            updated_at: new Date().toISOString()
          },
          { onConflict: "user_id" }
        );

        await service
          .from("profiles")
          .update({ plan, reports_quota: PLAN_QUOTAS[plan] ?? 3 })
          .eq("id", userId);
        break;
      }

      case "subscription.canceled":
      case "subscription.revoked": {
        const userId = data?.metadata?.user_id;
        if (!userId) break;

        await service
          .from("subscriptions")
          .update({ status: "canceled", updated_at: new Date().toISOString() })
          .eq("user_id", userId);

        await service
          .from("profiles")
          .update({ plan: "free", reports_quota: PLAN_QUOTAS.free })
          .eq("id", userId);
        break;
      }

      default:
        break;
    }
  } catch (err) {
    console.error("Polar webhook processing error:", err);
    return NextResponse.json({ error: "Webhook processing failed." }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
