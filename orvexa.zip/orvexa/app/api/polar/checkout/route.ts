import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

const PLAN_PRODUCT_IDS: Record<string, string | undefined> = {
  starter: process.env.POLAR_PRODUCT_STARTER,
  pro: process.env.POLAR_PRODUCT_PRO,
  agency: process.env.POLAR_PRODUCT_AGENCY
};

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const body = await req.json().catch(() => null);
  const plan = body?.plan as string;
  const productId = PLAN_PRODUCT_IDS[plan];

  if (!productId) {
    return NextResponse.json({ error: "Unknown plan." }, { status: 400 });
  }

  const res = await fetch("https://api.polar.sh/v1/checkouts/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.POLAR_ACCESS_TOKEN}`
    },
    body: JSON.stringify({
      product_id: productId,
      customer_email: user.email,
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?upgraded=1`,
      metadata: { user_id: user.id, plan }
    })
  });

  if (!res.ok) {
    console.error("Polar checkout creation failed:", await res.text());
    return NextResponse.json({ error: "Could not start checkout." }, { status: 502 });
  }

  const data = await res.json();
  return NextResponse.json({ url: data.url });
}
