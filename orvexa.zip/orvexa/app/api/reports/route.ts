import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

export async function GET(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const search = req.nextUrl.searchParams.get("q")?.trim();

  let query = supabase
    .from("reports")
    .select("id, site_url, title, report_json, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (search) {
    query = query.or(`title.ilike.%${search}%,site_url.ilike.%${search}%`);
  }

  const { data, error } = await query;

  if (error) return NextResponse.json({ error: "Failed to load history." }, { status: 500 });

  return NextResponse.json({ reports: data });
}
