import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Orvexa — AI SEO Sales Copilot",
  description:
    "Turn any prospect website into a sales angle in seconds. Audit the site. Find the opportunity. Write the pitch.",
  icons: {
    icon: "/logo.svg",
    shortcut: "/logo.svg",
    apple: "/logo.svg"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
