import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const next = req.nextUrl.searchParams.get("next") ?? "/dashboard";

  if (!code) {
    return NextResponse.redirect(new URL("/?error=auth_failed", req.url));
  }

  const supabase = createServerSupabase();
  const { data, error } = await supabase.auth.exchangeCodeForSession(code);

  if (error || !data.user) {
    return NextResponse.redirect(new URL("/?error=auth_failed", req.url));
  }

  // Bootstrap the profile row on first sign-in. Uses the service-role client
  // because a brand-new user's RLS-scoped session may race the insert.
  const service = createServiceSupabase();
  const { data: existing } = await service
    .from("profiles")
    .select("id")
    .eq("id", data.user.id)
    .maybeSingle();

  if (!existing) {
    await service.from("profiles").insert({
      id: data.user.id,
      email: data.user.email,
      full_name: data.user.user_metadata?.full_name ?? data.user.user_metadata?.name ?? "",
      avatar_url: data.user.user_metadata?.avatar_url ?? "",
      plan: "free",
      reports_quota: 3,
      reports_used: 0
    });
  }

  return NextResponse.redirect(new URL(next, req.url));
}
