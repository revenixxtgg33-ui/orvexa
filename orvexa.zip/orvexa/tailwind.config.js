/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        base: {
          950: "#08090b",
          900: "#0d0f12",
          850: "#121419",
          800: "#181b21",
          700: "#22262e",
          600: "#2e333d",
          border: "#23262d"
        },
        accent: {
          DEFAULT: "#6e5bff",
          soft: "#8f7fff",
          dim: "#4c3fc9"
        }
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"]
      },
      boxShadow: {
        card: "0 1px 0 rgba(255,255,255,0.04) inset, 0 8px 24px -12px rgba(0,0,0,0.5)",
        glow: "0 0 0 1px rgba(110,91,255,0.4), 0 0 40px -10px rgba(110,91,255,0.55)"
      },
      borderRadius: {
        xl2: "1.25rem"
      }
    }
  },
  plugins: []
};
